using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public static class FPagamento: Empresa{

    public list<cobrador,motorista,mecanico,auxiliar,administradores,vigilante> CategoriaSalarios;
    public int Nfuncionarios;
    public float FolhaPonto;
    public float Thorasextras;
    public double TFolhapagto;
    


}   