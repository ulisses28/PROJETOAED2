using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;


namespace classedeOnibus{
// Levantamento do numero de usúarios do sistema de transporte de cada bairro,e os horarios com maior circulação de pessoas.
    class Onibus;Empresa{
        private string cor_Bus;
        public bool Nportas;
        public float cartãoPassagem;
        private string Nlinha;
        public float ValorPassagem;
        }
        
        public void Passagem(float P){
            Passagem = P;
            
        }
        // Atributo cor do onibus 
        private void cor_Bus(string c){
            cor_Bus = c;
        }
        public void portas(bool tP){
            tamanho = tP
        }
        private void setnLinha (string nl){
            nLinha = nl
        }
        public bool getcartãoPassagem(){
            float saldo = 175.6;
            if(_cartãoPassagem = saldo){
                return true ;
                
            }
            else{
                Console.WriteLine("Saldo insuficiente")
                
            }
            
        }
        public void contrPortas(int TipoBus){
            if(qtdPessoas > convencional){
                return false;
            }
            else{
                return true;
                Console.WriteLine("Porta liberada");
            }
            if(qtdPessoas > Articulado){
                return false;
            }
            else{
                return true;
                console.WriteLine("Porta liberada");
            }
        }
        public void roleta(float PagPassagem){

            if(roleta = valorPassagem){
                qtdPessoas += 1;
                return true;
    
            }
            else{
                return false;
                Console.WriteLine("Aguardar pagamento")
                //Aguardar o pagamento da passagem.
            }
            if(roleta = cartãoPassagem & cartãoPassagem == saldo & cartãoPassagem > 3.75){
                cartãoPassagem -= Passagem;
                qtdPessoas += 1
                armazenaValor += Passagem;
                return true;
            }
            else{
                return false
            }
            
        }
        // valadidando se existe saldo no cartão.
        public void validaCartao(bool Vc){
            validaCartão = Vc;
            if(cartãoPassagem > 3.75 & cartãoPassagem == saldo){
                return true;
            }
            else{
                return false "Cartao sem saldo";
            }  
        }
        public static int qtdPessoas(){
            if(roleta == true){
                qtdPessoas += 1;
            }
            else{
                return false
            }
        }
        
    }

}