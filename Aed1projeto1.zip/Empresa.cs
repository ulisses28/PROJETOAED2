using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public class Empresa{
    // utilizar uma array para passar parâmetros da matriz que armazeará os dados das 3 empresas.
    private int Nfuncionarios;
    public int qtFrota;
    public string Tamanho;
    public double Salario;

    public void Nfuncionarios(int qf){
        Nfuncionarios = qf;  
    }
    public void  qtFrota(int frota){
        qtFrota = frota;
    }
    public void Tamanho(string Porte){
        Tamanho = Porte;
    }
    public double FolhaPagamento(double FP){
        FolhaPagamento = FP;
    }
    public static bool ContratarFuncionarios(){
        if(ContratarFuncionarios = true){
            Nfuncionarios += ContratarFuncionarios;
            return Nfuncionarios;
        }
        else{
            return false;
            Console.WriteLine(" Não houve contratações");
        }
    }
    public static void LerDados(string Cadastro){
        LerDados = DadosCadastro;
        string = "S","N"
        Console.WriteLine("Deseja ver os Dados cadastrais? S/N")
        string LerDados = Console.ReadLine();
        if(LerDados == "S"){
            return DadosCadastro;
        }
        else{
            return false;
        }
    }

       
}
