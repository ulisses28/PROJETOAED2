using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public class Maquineta{

    public string Nmaquina;
    protected double C_Transporte;
    protected double C_Estudante;
    public double ValorPassagem;

    public void Nmaquina(string NomeMaq){
        Nmaquina = NomeMaq;
    }
    public void C_Transporte(double VTransporte){
        C_Transporte = CT;
    }
    public void C_Estudante(double VEstudante){
        C_Estudante = CE;
    }
    public void ValorPassagem(double Passagem){
        ValorPassagem = Passagem;
    }
    public static bool Recarga(){
        double valor, saldo;
        Console.WriteLine("Qual modalidade deseja recarregar C_Estudante/C_Transporte")
        string tipo = Console.WriteLine();
        Console.WriteLine("O valor que deseja recarregar");
        double valor = Console.ReadLine();
        if(Recarga == C_Estudante){
        double valor = Console.ReadLine();
        C_Estudante += valor
        return C_Estudante;
        }
        else{
            if(Recarga == C_Transporte){
            C_Transporte += valor
            C_Estudante = Saldo
            return Saldo;
        }
    }
    public double Npassagem(){
        Npassagem = Saldo/passagem;
        return Npassagem;
    }
    public void bool ValidarPassagem(){
        if(C_Estudante > passagem){
            return true;
        }
        else{
            if(C_Transporte > passagem){
                return true;
            }
            else{
                retur false
                Console.WriteLine("Saldo insuficiente");
            }
        }
        public static double RecargaCartão(){
        double valor;
        double valor = Console.ReadLine(); 
        if(RecargaCartão == true){
            RecargaCartão += valor;
            CartaoTransporte = RecargaCartão;
            return CartaoTransporte;
        }
        else{
            return false;
            Console.WriteLine("Não houve recarga!")
        }
    }
