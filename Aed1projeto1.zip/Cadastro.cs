using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

namespace copiaCadastro{
    public class Cadastro{
        
        string[] DadosCadastro = new string[5];
        private  string inscricao;
        private  string Nome;
        public  static string Endereço;
        public int qtOnibus;
        

        public void Ninscricao(string Cnpj){
            inscricao = Cnpj;
            return Cnpj;

        }
        public static Nome(string NomeEmpresa){
            Nome = NomeEmpresa
            return NomeEmpresa

        }
        public static void Endereço(string Rua,string Ba,string Cid,string Estado){
            return Endereço;

        }
        public static void telefone(int tel){
            telefone = tel;
            return tel
        }
        public static Porte(bool Empresa){
            if(Nfuncionarios < 500){
                Porte = "Pequeno porte";
                return porte;

            }
            else{
                if(Nfuncionarios >500 && Nfuncionarios < 1500){
                    porte = "Médio porte"
                }
                else{
                    porte = "Grande porte"
                }
            }

        }
        public static void string DadosCadastro(){
            
            string NomeEmpresa = vet[0];
            string Ninscricao = vet[1];
            string telefone = vet[2];
            string Endereço = vet[3];
            string Porte = vet[4];
            return DadosCadastro
        }
    }
}