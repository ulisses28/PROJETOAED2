using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

    class Frota;{
        private int qtdFrota;
        private float qtdTanque;
        private float velocidade;
      
        
    }
    public  void qtdFrota1(int F){
        qtdFrota1 = F;
        
    }
    
    public  void set qtdTanque(float qt){
        qtdTanque = qt;
        
    }
    private void velocidade(float V){
        velocidade = v;
    
    }
    public static bool ComprarFrota(){
        if(ComprarFrota = true){
            qtFrota += ComprarFrota;
            return qtFrota;
        }
        else{
            return false;
            Console.WriteLine("Não houve compra de veículos");
        }

    }
    public void validVelocidade(bool speed){
        validVelocidade = speed;
        if(velocidade > 90){
            Console.WriteLine("Velocidade acima do permitido. Reduza a velocidade!")
            return false;
        }
        else{
            return true;

            // não retornar nenhuma mensagem!
        }
        public void calcularFrota(double cal){
            double patrimonio;
            calcularFrota = cal;
            patrimonio = 

        }
    }
}