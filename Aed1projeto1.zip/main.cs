using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

namespace ManipulandoClasses{
    class Program{
        static void Main(string[] args){
            Onibus bus = new Onibus("Azul", 4, 120, "801", 3.75);
            bus.roleta();
            Onibus cr = new Onibus(72 = true,128 = true);
            cr.contrPortas()
            Onibus vl = new Onibus(saldo = true )
            vl.validaCartao();
            Onibus a =  new Onibus(2.500f)
            List <Empresa> x  = new Empresa();
            x.empresa();
            Console.WriteLine("ler os dados", + bus);
            Console.WriteLine("ler os dados", + cr);
            Console.WriteLine("ler os dados", + vl);
            Console.WriteLine("ler os dados", + x);
        }
    }
}