using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public static class ControladorBus{

    public float ValorPassagem;
    public int CapacidadePessoas;
    private float CartaoPassagem;
    public double velocidade;
    public double SaldoCartão;

    class static ControladorBus(){
        ValorPassagem = 0;
        CapacidadePessoas = c;
        CartaoPassagem = P;
        velocidade = V;
        SaldoCartão = 0;
    }
    public static void ValorPassagem(float vp){
        ValorPassagem = vp;
    }
    public static void CartaoPassagem(float c){
        CartaoPassagem = c;
    }
    public static void CartaoPassagem(float P){
        CartaoPassagem = p;
    }
    public void velocidade(float V){
        velocidade = V;
    }
    public static void SaldoCartão(float SC){
        SaldoCartão = SC;
    }
    public static bool ValidarCPessoas(){
        if(ValidarCPessoas < CapacidadePessoas){
            Console.WriteLine("Capacidade dentro dos limites! ");
            return true;
        }
        else{
            Console.WriteLine("Capacidade Exedida!");
            return false;
        }
    }
    public static float RecarregarCartão(){
        float valor;
        Console.WriteLine("Qual valor deseja Recarregar? ");
        float RecarregarCartão = int.Parse(Console.ReadLine());
        CartaoPassagem = RecarregarCartão;
    }
    public static bool ValidarPagamento(){
        if(CartaoPassagem > ValorPassagem)){
            Console.WriteLine("Roleta Liberada!");
            return true;
        }
        else{
            Console.WriteLine("Saldo insuficiente!");
            return false;
        }
    }

}