using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public static class ControladorBus{

    public static float ValorPassagem;
    public static int CapacidadePessoas;
    private static float CartaoPassagem;
    public static double velocidade;
    public static double SaldoCartão;

    class static ControladorBus(){
        ValorPassagem = 0;
        CapacidadePessoas = c;
        CartaoPassagem = P;
        velocidade = V;
        SaldoCartão = 0;
    }
    public static void ValorPassagem(float vp){
        ValorPassagem = vp;
    }
    public static void CartaoPassagem(float c){
        CartaoPassagem = c;
    }
    public static void CartaoPassagem(float P){
        CartaoPassagem = p;
    }
    public void velocidade(float V){
        velocidade = V;
    }
    public static void SaldoCartao(float SC){
        SaldoCartão = SC;
    }
    public static bool ValidarCPessoas(){
        if(ValidarCPessoas < CapacidadePessoas){
            Console.WriteLine("Capacidade dentro dos limites! ");
            return true;
        }
        else{
            Console.WriteLine("Capacidade Exedida!");
            return false;
        }
    }
    public static float RecarregarCartão(){
        float valor;
        Console.WriteLine("Qual valor deseja Recarregar? ");
        float RecarregarCartão = int.Parse(Console.ReadLine());
        CartaoPassagem = RecarregarCartão;
        return CartaoPassagem;
    }
    public static bool ValidarPagamento(){
        if(CartaoPassagem > ValorPassagem)){
            Console.WriteLine("Roleta Liberada!");
            return true;
        }
        else{
            Console.WriteLine("Saldo insuficiente!");
            return false;
        }
    }

}