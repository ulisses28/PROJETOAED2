using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

namespace ManipulandoClasses{
    class Program{
        static void Main(string[] args){
           Cadastro cadastro = new Cadastro();
           FPagamento folha = new FPagamento();
           Empresa empresa = new Empresa();

           cadastro.Ninscricao("12325589/000179");
           cadastro.Nome("Serramar");
           cadastro.Nfuncionarios(1575);
           cadastro.Endereco("Rua Castro Neves,574,Serra/Espirito Santo-Brasil");
           cadastro.telefone("(27)3053-1978");

           Console.WriteLine("O nemero de inscrição Social: ",+ Ninscricao);
           Console.WriteLine("Nome da empresa: "+ nome);
           Console.WriteLine("Esta em possui {0} Funcionarios", Nfuncionarios);

           Console.WriteLine(cadastro.Porte());
           folha.Nfuncionarios(1230);
           folha.salario(3728.35);
           folha.HorasTrabalhadasMES(220)
           folha.HorasTrabalhadasDia(9);
           folha.Faltas_Atrasos(2.15));
           Console.WriteLine(FPagamento.Inss(0,08));
           Console.WriteLine(FPagamento.ThorasExtras(42));
           Cadastro.WriteLine(FPagamento.AumentoSindical(0.05));
           Console.WriteLine(FPagamento.PlanoSaude());
           Console.WriteLine("valor da hora de trabalho"FPagamento.ValorHora());
           Console.WriteLine(FPagamento.ValorExtra());
           Console.WriteLine(FPagamento.Descontos());
           Console.WriteLine(FPagamento.SalarioLiquido());
           Console.WriteLine(FPagamento.SalarioBruto());
           
           ControladorBus controlador = new ControladorBus();

           

        
        }
    }
}