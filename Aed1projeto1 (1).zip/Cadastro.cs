using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

namespace copiaCadastro{
    public class Cadastro{
        
        string[] DadosCadastro = new string[5];
        private  string inscricao;
        private  string Nome;
        public int Nfuncionarios;
        public  static string Endereço;
        public int qtOnibus;
        

        public void Ninscricao(string Cnpj){
            inscricao = Cnpj;

        }
        public void Nome(string N){
            Nome = N;

        }
        public static void Endereço(End){
            Endereço = end;
        }
        public void Nfuncionarios(int FPagamento){
            return Nfuncionarios;
        }
        public static void telefone(int tel){
            telefone = tel;
        
        }
        public static bool Porte(){
            if(Nfuncionarios < 500){
                Console.WriteLine("Pequeno porte");
            }
            else if(Nfuncionarios < 3000){
                    Console.WriteLine("Médio porte");
                    
                }
                else{
                    Console.WriteLine("Grande porte");
                    
                }
            }

        }
       
    }
}