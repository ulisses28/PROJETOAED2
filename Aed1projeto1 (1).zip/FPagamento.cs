using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;
// Classe pai de empresa 
public static class FPagamento: Empresa{

    
    public int Nfuncionarios;
    public float Salario;
    private float HorasTrabalhadasMES;
    private float HorasTrabalhadasDia;
    public float Faltas_Atrasos;
    public float Inss;
    public float THorasExtras;
    public double AumentoSindical;
    

    public void Nfuncionarios(int NF){
        Nfuncionarios = NF;
    }

    public void Salario(float S){
        Salario = S;
    }
    public void HorasTrabalhadasMes(float HT){
        HorasTrabalhadas = HT;
    }

    public void TotalHorasDia(float TD){
        TotalHorasDia = TD;
    }

    public void Faltas_Atrasos(float FA){
        Faltas_Atrasos = FA;
    }

    public void Inss(float I){
        Inss = I;
    }

    public void THorasExtras(float TE){
        THorasExtras = TE
    }

    public void AumentoSindical(float AU){
        AumentoSindical = AU;
    }

    public bool PlanoSaude(){
        Console.WriteLine("Sua idade? ");
        int idade = int.Parse(Console.ReadLine());
        PlanoSaude = Plano;
        if(Plano == true & idade > 18 & idade < 25){
            Plano = 70
            return Plano;
        }
        else if(idade < 30){
            plano = 94;
            Console.WriteLine("A sua idade é {0}");
            return Plano;
        }
        else if(idade < 45){
            Plano = 145;
            Console.WriteLine("A sua idade é {0}");
            return Plano;
        }
        else if(idade < 60){
            Plano = 225;
            return Plano;
        }
        else if(idade > 60){
            plano = 300;
            Console.WriteLine("A sua idade é {0}")
            return Plano;
        }
        else{
            Console.WriteLine("O funcionário não aderiu ao plano");
            return false;
        }
    }
    
    // Esse método calcula o valor da hora trabalhada,refereste ao salario de cada funcionário.
    public static double ValorHora(){
        ValorHora = Salario / HorasTrabalhadasMES;
        return ValorHora;
    }

    public static double ValorExtra(){
        // Calcula o valor da hora extra dia feito pelo funcionário,considerando que o dia da hora extra vale 100%.
        ValorExtra = (THorasExtras*ValorHora)*2;
        return ValorExtra;  
    }
    public static float Descontos(){
        Descontos = (Salario * Inss)+PlanoSaude+(Faltas_Atrasos * ValorHora);
        return Descontos;
    }
    public static float SalarioLiquido(){
        SalarioLiquido = (Descontos - Salario)+ValorExtra;
        return SalarioLiquido;
    }
    public float SalarioBruto(){
        SalarioBruto = salario + ValorExtra;
        return SalarioBruto;
    }

    


    


}   