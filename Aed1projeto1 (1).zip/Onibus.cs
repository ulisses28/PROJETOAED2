using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;


namespace classedeOnibus{
// Levantamento do numero de usúarios do sistema de transporte de cada bairro,e os horarios com maior circulação de pessoas.
    class Onibus:ControladorBus{
        public string cor;
        public double Tamanho;
        public float CapTanque;

        public void cor(string cr){
            cor = cr;
        }
        public void Tamanho(double T){
            Tamanho = T;
        }
        public void CapTanque(float CT){
            CapTanque = CT;

        }

        
    }

}