using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public class Empresa:FPagamento{
    public string Diretor;
    // Nome do diretor da empresa.
    public void Diretor(string nome){
        Diretor = nome;

    }
    
    
    
    

       
}
