using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

public static class ControladorBus{

    private static float ValorPassagem;
    public static int CapacidadePessoas;
    private static float CartaoPassagem;
    public static double velocidade;
    public static double SaldoCartão;

    class static ControladorBus(){
        ValorPassagem = 0;
        CapacidadePessoas = c;
        CartaoPassagem = P;
        velocidade = V;
        SaldoCartão = 0;

        // Atributo que define um valor unico para passagem do sistema de transporte,sendo usado o conceito de estatico para que esse atributo não seja modificado por nenhuma variável de outra classe
        public static void ValorPassagem(float vp){
            ValorPassagem = vp;
        }
        // Esse atributo "CartaoPassagem" ele representa o cartão de passagem do transporte coletivo,onde ele atravez do método "RecarregarCartão" introduzira uma especie de valor em quantia referente a dias de utilização do cartão transporte.
        public static void CartaoPassagem(float c){
            CartaoPassagem = c;
        }
        // Esse atributo define a quantidade maxima de pessoas que um onibus comporta,considerando pessoas sentadas mais pessoas em pé.
        public static void CapacidadePessoas(float cp){
            CartaoPassagem = cp;
        }
        // Atributo define a velocidade maxima que o onibus pode atingir.
        public void velocidade(float V){
            velocidade = V;
        }

        public static void SaldoCartao(float RecarregarCartão){
            SaldoCartão = RecarregarCartão;
        }
        public static bool ValidarCPessoas(){
            if(ValidarCPessoas < CapacidadePessoas){
                Console.WriteLine("Capacidade dentro dos limites! ");
                return true;
            }
            else{
                Console.WriteLine("Capacidade Exedida!");
                return false;
            }
        }
        public static float RecarregarCartão(){
            float valor;
            Console.WriteLine("Qual valor deseja Recarregar? ");
            float RecarregarCartão = int.Parse(Console.ReadLine());
            CartaoPassagem = RecarregarCartão;
            return CartaoPassagem;
        }
        public static bool ValidarPagamento(){
            if(CartaoPassagem > ValorPassagem)){
                Console.WriteLine("Roleta Liberada!");
                return true;
            }
            else{
                Console.WriteLine("Saldo insuficiente!");
                return false;
            }
        }

}