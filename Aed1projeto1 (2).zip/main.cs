using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

namespace ManipulandoClasses{
    class Program{
        static void Main(string[] args){
           Cadastro cadastro = new Cadastro();
           FPagamento folha = new FPagamento();
           Empresa empresa = new Empresa();
        // passando os parâmetros da classe "Cadastro".
           cadastro.Ninscricao("12325589/000179");
           cadastro.Nome("Serramar");
           cadastro.Nfuncionarios(1575);
           cadastro.Endereco("Rua Castro Neves,574,Serra/Espirito Santo-Brasil");
           cadastro.telefone("(27)3053-1978");
        // Leitura dos dados
           Console.WriteLine("O nemero de inscrição Social: ",+ cadastro.Ninscricao);
           Console.WriteLine("Nome da empresa: "+ cadastro.Nome);
           Console.WriteLine("Esta em possui {0} Funcionarios", cadastro.Nfuncionarios);
           Console.WriteLine(cadastro.Porte());
        // Instanciando a classe Folha de pagamento que e pai de empresa
           FPagamento folha = new FPagamento();
           Empresa empresa = new Empresa();

           folha.Nfuncionarios(1230);
           folha.salario(3728.35);
           folha.HorasTrabalhadasMES(220)
           folha.HorasTrabalhadasDia(9);
           folha.Faltas_Atrasos(2.15));
           empresa.Diretor("Mittal Lakashim");
           Console.WriteLine(FPagamento.Inss(0,08));
           Console.WriteLine(FPagamento.ThorasExtras(42));
           Cadastro.WriteLine(FPagamento.AumentoSindical(0.05));
           Console.WriteLine(FPagamento.PlanoSaude());
           Console.WriteLine("valor da hora de trabalho"FPagamento.ValorHora());
           Console.WriteLine(FPagamento.ValorExtra());
           Console.WriteLine(FPagamento.Descontos());
           Console.WriteLine(FPagamento.SalarioLiquido());
           Console.WriteLine(FPagamento.SalarioBruto());
           Console.WriteLine("O diretor da empresa é: ",+ bus.Diretor);
           
           ControladorBus controlador = new ControladorBus();
           Onibus bus = new Onibus();

           Console.WriteLine(controlador.ValorPassagem(3.75));
           Console.WriteLine(controlador.CapacidadePessoas(110));
           Console.WriteLine(controlador.CartaoPassagem(60.00));
           Console.WriteLine(controlador.Velocidade(120));
           Console.WriteLine(controlador.ValorPassagem(3.75));
           Console.WriteLine(controlador.SaldoCartao(controlador.CartaoPassagem));
           Console.WriteLine(controlador.ValidarPessoas);
           Console.WriteLine(controlador.RecarregarCartao);
           Console.WriteLine(controlador.ValidarPagamento);
           // passando parâmetro dos atributos da classe "Onibus".
           bus.Cor("Azul");
           bus.Tamanho(12.75);
           bus.CapTanque(200,25;2f);
           bus.Nlinha(805)

           

        
        }
    }
}